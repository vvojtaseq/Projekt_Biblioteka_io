#include "Egzemplarz.h"
