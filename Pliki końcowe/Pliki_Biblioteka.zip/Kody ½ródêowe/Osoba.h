#pragma once
#include "Includy.h"
#define MAXPESEL 99999999999
#define MINPESEL 1000000000
#define PESELLENGTH 11
class Osoba
{
private:
	std::string Imie;
	std::string Nazwisko;
	std::string Adres;
	std::string DataUrodzenia;
	std::string Telefon;
	std::string PESEL;
	std::string Email;
	unsigned int ID;
	std::string Haslo;
	int PowerLevel; //0 - czytelnik, 1 - pracownik

public:
	//metody 
	//trzeba zrobic metody get i set, set potrzebne do tworzenia uzytkownika, get do logowania i innych klas 
	std::string getImie() { return Imie; }
	void setImie(std::string noweImie)
	{ 
		Imie = noweImie;
		//std::cout << Imie << std::endl;
	}
	std::string getNazwisko() { return Nazwisko; }
	void setNazwisko(std::string noweNazwisko) 
	{ 
		Nazwisko = noweNazwisko;
		//std::cout << Nazwisko << std::endl;
	}
	std::string getAdres() { return Adres; }
	void setAdres(std::string nowyAdres)
	{
		Adres = nowyAdres;
		//std::cout << Adres << std::endl;
	}
	std::string getDataUrodzenia() { return DataUrodzenia; }
	void setDataUrodzenia(std::string nowaDataUrodzenia) 
	{ 
		DataUrodzenia = nowaDataUrodzenia;
		//std::cout << DataUrodzenia << std::endl; 
	}
	std::string getTelefon() { return Telefon; }
	void setTelefon(std::string nowyTelefon)
	{
		Telefon = nowyTelefon;
		//std::cout << Telefon << std::endl;
	}
	std::string getPESEL() { return PESEL; }
	void setPESEL(std::string nowyPESEL)
	{
		PESEL = nowyPESEL;
	}

	unsigned int getID() { return ID; }

	void setManualID(unsigned int id) { ID = id; }

	void setID() {
		std::ifstream plik("czytelnicy.txt");
		std::string linia;
		int ostatnieID1 = 0;
		int ostatnieID2 = 0;

		//ostatnia linia w pliku to ostatni uzytkownik
		while (getline(plik, linia))
		{
			std::stringstream ss(linia);
			std::string id;
			getline(ss, id, '|');
			ostatnieID1 = std::stoi(id);
		}
		plik.close();
		std::ifstream plik2("bibliotekarze.txt");
		while (getline(plik2, linia))
		{
			std::stringstream ss(linia);
			std::string id;
			getline(ss, id, '|');
			ostatnieID2 = std::stoi(id);
		}
		plik2.close();
		if(ostatnieID1 > ostatnieID2)
		{
			ID = ostatnieID1 + 1;
		}
		else
		{
			ID = ostatnieID2 + 1;
		}
	}
	
	std::string getHaslo() { return Haslo; }
	void setHaslo(std::string noweHaslo) { Haslo = noweHaslo; }

	void setPowerLevel(int powerlevel) { PowerLevel = powerlevel; };
	int getPowerLevel() { return PowerLevel; };

	void setEmail(std::string email) {
		if (email.find("@") == std::string::npos || email.find(".") == std::string::npos)
		{
			std::cout << "Niepoprawny adres email. Wprowadz ponownie." << std::endl;
			std::cin >> email;
			setEmail(email);

		}
		else
		{
			Email = email;
		}
	}
	std::string getEmail() { return Email; }

	//konstruktor

	Osoba() {};

Osoba(std::string imie, std::string nazwisko, std::string adres, std::string dataUrodzenia, std::string telefon, std::string pesel, std::string email, std::string haslo, int powerlevel)
	{
		setImie(imie);
		setNazwisko(nazwisko);
		setAdres(adres);
		setDataUrodzenia(dataUrodzenia);
		setTelefon(telefon);
		setPESEL(pesel);
		setEmail(email);
		setHaslo(haslo);
		setPowerLevel(powerlevel);
		setID();
	}

	
};
	/*
	void setPESEL( std::string nowyPESEL) {
		if (nowyPESEL.length() != PESELLENGTH) {
			std::cout << "Niepoprawna dlugosc numeru PESEL. Wprowadz 11 znakow." << std::endl;  
			std::cin >> nowyPESEL;
			setPESEL(nowyPESEL);
		}

		if (!std::all_of(nowyPESEL.begin(), nowyPESEL.end(), ::isdigit)) {
			std::cout << "Numer PESEL powinien zawierac tylko cyfry." << std::endl;
			std::cin >> nowyPESEL;
			setPESEL(nowyPESEL);
		}

		long long pesel = std::stoll(nowyPESEL);

		if (pesel > MAXPESEL || pesel < MINPESEL) {
			std::cout << "Niepoprawny nr PESEL. Numer PESEL powinien zawierac 11 cyfr." << std::endl;
			std::cin >> nowyPESEL;
			setPESEL(nowyPESEL);
		}

		else {
			PESEL = nowyPESEL;
			std::cout << "Nowy pesel to: ";
		}
	}
	*/

