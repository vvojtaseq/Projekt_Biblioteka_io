//biblioteki
//do cpp i do plikow headerow klas
#include <iostream>
#include <iomanip>
#include <cctype>
#include <regex>
#include <windows.h>
#include <string>
#include <chrono> //ta biblioteka daje nam mozliwosc zapisywania dat
#include <sstream>
#include <ctime> //do czasu
#include <stdlib.h> // do system("CLS") czyli czyszczenia konsoli
#include <algorithm>
#include <cctype> // te dwa do std::all_of
#include <locale.h> // do polskich liter
#include <fstream> //do plikow

