#pragma once
#include "Includy.h"
#include "Osoba.h"

class Czytelnik : public Osoba
{

};

