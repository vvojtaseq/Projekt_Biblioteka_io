#pragma once
// to jest tylko do cpp gdzie musimy miec dostep do wszystkich klas
// NIE DODAJEMY DO KLAS
#include "Osoba.h"
#include "Bibliotekarz.h"
#include "Czytelnik.h"
#include "KatalogUzytkownikow.h"
#include "Ksiazka.h"
#include "Autor.h"
#include "Egzemplarz.h"
#include "Wypozyczenia.h"
#include "Zbior.h"
#include "KartaBiblioteczna.h"
#include "Dlug.h"
// inne pliki

#include "UI.h"