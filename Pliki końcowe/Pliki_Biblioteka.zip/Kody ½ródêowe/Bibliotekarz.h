#pragma once
#include "Includy.h"
#include "Osoba.h"
class Bibliotekarz : public Osoba
{
	
	//chierarchia bibliotekarzy? Zakladam ze bedzie 1 albo 2 czy cos takiego, mozna to tez dodac do osoby i jak tworzymy obiekt typu czytelnik to
	//automatycznie power level 0, a jak bibliotekarza to mozemy np wybrac czy to pracownik czy menadzer czy cos takiego

};

